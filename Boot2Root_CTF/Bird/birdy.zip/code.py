data = None
with open("/home/main_user/Documents/Boot2Root_CTF/Bird/flag.bin", 'rb') as file:
    data = file.read()

print()